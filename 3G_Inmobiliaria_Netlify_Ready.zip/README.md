# 3G Inmobiliaria · versión lista para Netlify

Esta versión deja preparada la web para:
- login real de agentes con Supabase Auth
- propiedades compartidas entre varios usuarios
- citas guardadas en servidor
- formulario de contacto al servidor
- chatbot con IA usando una API privada segura en Netlify Functions
- valoración conectada a IA en backend con fallback local
- subida real de imágenes a Supabase Storage

## 1) Qué debes crear en Supabase

### Auth
1. Crea un proyecto en Supabase.
2. En Authentication > Users, crea los usuarios agentes con email y contraseña.
3. En SQL Editor, ejecuta `sql/schema.sql`.
4. En la tabla `agents`, añade los emails autorizados.

### Storage
Crea un bucket público llamado `property-images`.

## 2) Variables de entorno en Netlify

Añade estas variables con alcance para Functions:
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY
- ANTHROPIC_API_KEY
- PROPERTY_IMAGES_BUCKET=property-images

Netlify indica que las variables usadas por Functions deben configurarse con alcance para Functions. citeturn956299search0turn956299search3turn956299search15

## 3) Configuración pública del frontend

Copia `config.example.js` a `config.js` y rellena:
- supabaseUrl
- supabaseAnonKey

La anon key es publicable; la service role key nunca debe ir en el navegador. Supabase separa claves publicables de las de servidor en su documentación. citeturn956299search4turn956299search10

## 4) Despliegue en Netlify

1. Sube esta carpeta a un repositorio Git.
2. Crea un sitio en Netlify desde ese repo.
3. Publish directory: `.`
4. Las Functions quedarán en `/.netlify/functions/...`.

Netlify documenta que las Functions se despliegan junto al sitio y se sirven en esa ruta. citeturn956299search3turn956299search15

## 5) Chat IA seguro

La clave de Anthropic se usa solo en backend. La llamada correcta al endpoint Messages usa `x-api-key` y `anthropic-version`. citeturn956299search11turn956299search17
