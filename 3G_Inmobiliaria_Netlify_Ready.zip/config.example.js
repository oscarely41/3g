window.__3G_CONFIG__ = {
  phone: '+34 600 000 000',
  email: 'info@3gasesores.com',
  supabaseUrl: 'https://TU-PROYECTO.supabase.co',
  supabaseAnonKey: 'TU_SUPABASE_ANON_KEY_PUBLICA'
};
