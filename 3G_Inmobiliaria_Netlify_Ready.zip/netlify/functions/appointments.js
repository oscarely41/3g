import { getAdminClient, getAgentFromRequest } from './utils/supabase.js';
import { ok, options, badRequest, unauthorized, serverError } from './utils/response.js';

export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return options();
  const supabase = getAdminClient();

  try {
    if (event.httpMethod === 'GET') {
      const qs = event.queryStringParameters || {};

      if (qs.scope === 'full') {
        const auth = await getAgentFromRequest(event);
        if (!auth) return unauthorized();
        const { data, error } = await supabase
          .from('appointments')
          .select('id,property_id,property_name,client_name,client_phone,client_email,scheduled_date,scheduled_time,status,created_at')
          .order('scheduled_date', { ascending: true })
          .order('scheduled_time', { ascending: true });
        if (error) throw error;
        const appointments = (data || []).map(row => ({
          id: row.id,
          propId: row.property_id,
          propNombre: row.property_name,
          nombre: row.client_name,
          tel: row.client_phone,
          email: row.client_email,
          fecha: row.scheduled_date,
          hora: row.scheduled_time,
          status: row.status
        }));
        return ok({ appointments });
      }

      if (qs.month) {
        const start = `${qs.month}-01`;
        const date = new Date(`${start}T00:00:00Z`);
        const endDate = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth() + 1, 1));
        const end = endDate.toISOString().slice(0, 10);
        const { data, error } = await supabase
          .from('appointments')
          .select('scheduled_date')
          .gte('scheduled_date', start)
          .lt('scheduled_date', end);
        if (error) throw error;
        const map = new Map();
        for (const row of (data || [])) map.set(row.scheduled_date, (map.get(row.scheduled_date) || 0) + 1);
        return ok({ summary: Array.from(map.entries()).map(([date, count]) => ({ date, count })) });
      }

      if (qs.date && qs.propId) {
        const { data, error } = await supabase
          .from('appointments')
          .select('scheduled_time')
          .eq('scheduled_date', qs.date)
          .eq('property_id', Number(qs.propId));
        if (error) throw error;
        return ok({ bookedHours: (data || []).map(x => x.scheduled_time) });
      }

      return badRequest('Consulta no válida');
    }

    if (event.httpMethod === 'POST') {
      const body = JSON.parse(event.body || '{}');
      if (!body.propertyId || !body.clientName || !body.clientEmail || !body.scheduledDate || !body.scheduledTime) {
        return badRequest('Faltan datos obligatorios');
      }

      const { data: property, error: propError } = await supabase
        .from('properties')
        .select('id,nombre')
        .eq('id', Number(body.propertyId))
        .maybeSingle();
      if (propError) throw propError;
      if (!property) return badRequest('La propiedad no existe');

      const { data: existing, error: existingError } = await supabase
        .from('appointments')
        .select('id')
        .eq('property_id', Number(body.propertyId))
        .eq('scheduled_date', body.scheduledDate)
        .eq('scheduled_time', body.scheduledTime)
        .maybeSingle();
      if (existingError) throw existingError;
      if (existing) return badRequest('Ese horario ya está ocupado para esta propiedad');

      const payload = {
        property_id: Number(body.propertyId),
        property_name: property.nombre,
        client_name: body.clientName,
        client_phone: body.clientPhone || '',
        client_email: body.clientEmail,
        scheduled_date: body.scheduledDate,
        scheduled_time: body.scheduledTime,
        status: 'pending'
      };

      const { data, error } = await supabase.from('appointments').insert(payload).select('*').single();
      if (error) throw error;
      return ok({ appointment: data });
    }

    return badRequest('Método no permitido');
  } catch (error) {
    return serverError(error);
  }
}
