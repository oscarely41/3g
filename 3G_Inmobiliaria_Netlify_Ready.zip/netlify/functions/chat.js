import { ok, options, badRequest, serverError } from './utils/response.js';

export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return options();
  if (event.httpMethod !== 'POST') return badRequest('Método no permitido');

  try {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) throw new Error('Falta ANTHROPIC_API_KEY');

    const body = JSON.parse(event.body || '{}');
    if (!body.message) return badRequest('Falta el mensaje');

    const properties = Array.isArray(body.properties) ? body.properties : [];
    const contact = body.contact || {};

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-5',
        max_tokens: 500,
        system: `Eres el asistente web de 3G Inmobiliaria. Responde en español, con claridad comercial y sin inventar propiedades. Si no sabes algo, redirige al teléfono ${contact.phone || ''} y al email ${contact.email || ''}. Usa esta cartera resumida: ${JSON.stringify(properties).slice(0, 8000)}`,
        messages: [{ role: 'user', content: body.message }]
      })
    });

    if (!response.ok) throw new Error(await response.text());

    const data = await response.json();
    const text = data?.content?.map(part => part?.text || '').join('\n').trim() || 'Ahora mismo nuestros agentes pueden ayudarte por teléfono o email.';
    return ok({ reply: text });
  } catch (error) {
    return serverError(error);
  }
}
