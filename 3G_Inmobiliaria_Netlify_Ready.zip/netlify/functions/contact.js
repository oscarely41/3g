import { getAdminClient } from './utils/supabase.js';
import { ok, options, badRequest, serverError } from './utils/response.js';

export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return options();
  if (event.httpMethod !== 'POST') return badRequest('Método no permitido');

  try {
    const body = JSON.parse(event.body || '{}');
    if (!body.name || !body.email || !body.message) return badRequest('Faltan campos obligatorios');

    const supabase = getAdminClient();
    const { data, error } = await supabase.from('contact_leads').insert({
      name: body.name,
      email: body.email,
      phone: body.phone || '',
      message: body.message
    }).select('*').single();
    if (error) throw error;

    return ok({ lead: data, success: true });
  } catch (error) {
    return serverError(error);
  }
}
