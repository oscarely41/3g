import { getAgentFromRequest } from './utils/supabase.js';
import { ok, options, unauthorized, serverError } from './utils/response.js';

export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return options();
  if (event.httpMethod !== 'GET') return unauthorized('Método no permitido');
  try {
    const auth = await getAgentFromRequest(event);
    if (!auth) return unauthorized();
    return ok({ user: { id: auth.user.id, email: auth.user.email } });
  } catch (error) {
    return serverError(error);
  }
}
