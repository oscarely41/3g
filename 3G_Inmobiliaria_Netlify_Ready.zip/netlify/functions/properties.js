import { getAdminClient, getAgentFromRequest } from './utils/supabase.js';
import { ok, options, badRequest, unauthorized, serverError } from './utils/response.js';

export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return options();
  const supabase = getAdminClient();

  try {
    if (event.httpMethod === 'GET') {
      const { data, error } = await supabase
        .from('properties')
        .select('id,nombre,tipo,precio,zona,hab,metros,banos,ref,dir,desc,img_url,created_at')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return ok({ properties: data || [] });
    }

    const auth = await getAgentFromRequest(event);
    if (!auth) return unauthorized();

    if (event.httpMethod === 'POST') {
      const body = JSON.parse(event.body || '{}');
      if (!body.nombre || !body.precio) return badRequest('Nombre y precio son obligatorios');
      const payload = {
        nombre: body.nombre,
        tipo: body.tipo || 'piso',
        precio: Number(body.precio),
        zona: body.zona || 'vigo',
        hab: Number(body.hab || 0),
        metros: Number(body.metros || 0),
        banos: Number(body.banos || 0),
        ref: body.ref || '',
        dir: body.dir || '',
        desc: body.desc || '',
        img_url: body.img_url || null,
        created_by: auth.user.id
      };
      const { data, error } = await supabase.from('properties').insert(payload).select('*').single();
      if (error) throw error;
      return ok({ property: data });
    }

    if (event.httpMethod === 'DELETE') {
      const id = event.queryStringParameters?.id;
      if (!id) return badRequest('Falta id');
      const { error } = await supabase.from('properties').delete().eq('id', Number(id));
      if (error) throw error;
      return ok({ success: true });
    }

    return badRequest('Método no permitido');
  } catch (error) {
    return serverError(error);
  }
}
