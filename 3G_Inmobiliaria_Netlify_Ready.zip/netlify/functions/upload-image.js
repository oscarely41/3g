import { getAdminClient, getAgentFromRequest } from './utils/supabase.js';
import { ok, options, badRequest, unauthorized, serverError } from './utils/response.js';

function parseDataUrl(dataUrl) {
  const match = String(dataUrl || '').match(/^data:(.+?);base64,(.+)$/);
  if (!match) throw new Error('Formato de imagen no válido');
  return { mime: match[1], buffer: Buffer.from(match[2], 'base64') };
}

export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return options();
  if (event.httpMethod !== 'POST') return badRequest('Método no permitido');

  try {
    const auth = await getAgentFromRequest(event);
    if (!auth) return unauthorized();

    const body = JSON.parse(event.body || '{}');
    if (!body.dataUrl || !body.filename) return badRequest('Falta la imagen');

    const { mime, buffer } = parseDataUrl(body.dataUrl);
    const safeName = body.filename.toLowerCase().replace(/[^a-z0-9._-]/g, '-');
    const path = `${Date.now()}-${safeName}`;
    const bucket = process.env.PROPERTY_IMAGES_BUCKET || 'property-images';

    const supabase = getAdminClient();
    const { error } = await supabase.storage.from(bucket).upload(path, buffer, {
      contentType: mime,
      upsert: false
    });
    if (error) throw error;

    const { data } = supabase.storage.from(bucket).getPublicUrl(path);
    return ok({ publicUrl: data.publicUrl, path });
  } catch (error) {
    return serverError(error);
  }
}
