export function json(statusCode, payload) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS'
    },
    body: JSON.stringify(payload)
  };
}

export function ok(payload) { return json(200, payload); }
export function badRequest(message) { return json(400, { error: message }); }
export function unauthorized(message = 'No autorizado') { return json(401, { error: message }); }
export function serverError(error) { return json(500, { error: error?.message || 'Error interno del servidor' }); }
export function options() { return { statusCode: 204, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS' } }; }
