import { createClient } from '@supabase/supabase-js';

let cached = null;

export function getAdminClient() {
  if (cached) return cached;
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error('Faltan SUPABASE_URL o SUPABASE_SERVICE_ROLE_KEY');
  cached = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  return cached;
}

export async function getAgentFromRequest(event) {
  const token = event.headers.authorization?.replace(/^Bearer\s+/i, '') || '';
  if (!token) return null;
  const supabase = getAdminClient();
  const { data: userData, error: userError } = await supabase.auth.getUser(token);
  if (userError || !userData?.user?.email) return null;
  const email = userData.user.email.toLowerCase();
  const { data: agent, error: agentError } = await supabase
    .from('agents')
    .select('id,email,approved')
    .eq('email', email)
    .eq('approved', true)
    .maybeSingle();
  if (agentError || !agent) return null;
  return { user: userData.user, agent };
}
