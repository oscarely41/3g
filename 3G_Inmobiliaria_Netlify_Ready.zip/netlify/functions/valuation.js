import { ok, options, badRequest, serverError } from './utils/response.js';

function fallbackEstimate(payload) {
  const base = { piso: { vigo: 2350, bouzas: 2100, cangas: 1650, baiona: 2200, nigran: 2100, pontevedra: 1850 }, chalet: { vigo: 2100, bouzas: 1900, cangas: 1500, baiona: 2400, nigran: 2350, pontevedra: 1750 }, local: { vigo: 1750, bouzas: 1500, cangas: 1200, baiona: 1450, nigran: 1400, pontevedra: 1350 }, terreno: { vigo: 320, bouzas: 280, cangas: 160, baiona: 250, nigran: 230, pontevedra: 185 } };
  const estadoMult = { nuevo: 1.18, bueno: 1.0, reformar: 0.78 };
  const habBoost = payload.tipo === 'terreno' || payload.tipo === 'local' ? 1 : Math.min(1.12, 0.94 + Number(payload.hab || 0) * 0.03);
  const antiguedad = Math.max(0, new Date().getFullYear() - Number(payload.anyo || 2000));
  const depreciacion = Math.max(0.65, 1 - antiguedad * 0.0045);
  const precioBaseM2 = ((base[payload.tipo] || base.piso)[payload.zona] || 1800) * (estadoMult[payload.estado] || 1) * habBoost * depreciacion;
  const central = Math.round((precioBaseM2 * Number(payload.metros || 80)) / 1000) * 1000;
  return {
    estimatedPrice: central,
    minPrice: Math.round(central * 0.9),
    maxPrice: Math.round(central * 1.12),
    factors: [
      { name: 'Método', value: 'Estimación automática de respaldo' },
      { name: 'Precio m²', value: `${Math.round(precioBaseM2)} €/m²` },
      { name: 'Tipo', value: payload.tipo },
      { name: 'Zona', value: payload.zona },
      { name: 'Estado', value: payload.estado },
      { name: 'Antigüedad', value: `${antiguedad} años` }
    ]
  };
}

export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return options();
  if (event.httpMethod !== 'POST') return badRequest('Método no permitido');

  try {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    const body = JSON.parse(event.body || '{}');
    if (!body.tipo || !body.zona || !body.metros) return badRequest('Faltan datos para la valoración');
    if (!apiKey) return ok(fallbackEstimate(body));

    const prompt = `Devuelve solo JSON válido con este esquema:
{
  "estimatedPrice": 250000,
  "minPrice": 230000,
  "maxPrice": 275000,
  "factors": [{"name":"Método","value":"IA + heurística"}]
}
Datos del inmueble: ${JSON.stringify(body)}.
Contexto: vivienda en Galicia, enfoque Vigo y alrededores, responde con valores enteros en euros y factores breves en español.`;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-5',
        max_tokens: 500,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    if (!response.ok) return ok(fallbackEstimate(body));

    const data = await response.json();
    const text = data?.content?.map(part => part?.text || '').join('\n').trim() || '{}';
    const jsonStart = text.indexOf('{');
    const jsonEnd = text.lastIndexOf('}');
    const parsed = JSON.parse(text.slice(jsonStart, jsonEnd + 1));
    return ok(parsed);
  } catch (error) {
    return serverError(error);
  }
}
