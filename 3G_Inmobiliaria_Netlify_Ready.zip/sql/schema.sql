-- Ejecuta este script en el SQL Editor de Supabase.

create extension if not exists pgcrypto;

create table if not exists public.agents (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  approved boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.properties (
  id bigint generated always as identity primary key,
  nombre text not null,
  tipo text not null,
  precio numeric not null,
  zona text not null,
  hab integer not null default 0,
  metros integer not null default 0,
  banos integer not null default 0,
  ref text,
  dir text,
  desc text,
  img_url text,
  created_by uuid,
  created_at timestamptz not null default now()
);

create table if not exists public.appointments (
  id bigint generated always as identity primary key,
  property_id bigint not null references public.properties(id) on delete cascade,
  property_name text not null,
  client_name text not null,
  client_phone text,
  client_email text not null,
  scheduled_date date not null,
  scheduled_time text not null,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create unique index if not exists appointments_unique_slot
on public.appointments (property_id, scheduled_date, scheduled_time);

create table if not exists public.contact_leads (
  id bigint generated always as identity primary key,
  name text not null,
  email text not null,
  phone text,
  message text not null,
  created_at timestamptz not null default now()
);

insert into public.agents (email, approved)
values ('agente@3gasesores.com', true)
on conflict (email) do nothing;

-- Crea también un bucket público llamado "property-images" en Storage.
